package iotbay.servlet.shipment;

import iotbay.model.Shipment;
import iotbay.service.ShipmentService;
import iotbay.service.impl.ShipmentServiceImpl;
import iotbay.utils.R;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/shipment/findAll")
public class QueryServlet extends HttpServlet {

    private final ShipmentService shipmentService = new ShipmentServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Shipment shipment = new Shipment();
//        Customer customer = (Customer) req.getSession().getAttribute("customer");
        shipment.setCustomerId(1);
        String id = req.getParameter("id");
        if (id != null && !"".equals(id)) {
            shipment.setId(Integer.valueOf(id));
        }
        try {
            resp.getWriter().write(new JSONObject(R.ok().data("shipments",shipmentService.findAll(shipment))).toString());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
