package iotbay.utils;



import java.util.HashMap;
import java.util.Map;

/**
 */

public class R {

    private Integer code;
    private String message;
    private Boolean success;
    private Map<String, Object> data = new HashMap<String, Object>();

    private R(){}

    public static R ok(){
        R r = new R();
        r.setCode(20000);
        r.setMessage("Success");
        r.setSuccess(true);
        return r;
    }

    public static R error(){
        R r = new R();
        r.setCode(20001);
        r.setMessage("Fail");
        r.setSuccess(false);
        return r;
    }

    public static R auto(Boolean success){
        return success ? ok() : error();
    }

    public R code(Integer code){
        this.code = code;
        return this;
    }

    public R message(String message){
        this.message = message;
        return this;
    }

    public R success(Boolean success){
        this.success = success;
        return this;
    }

    public R data(String key , Object value){
        data.put(key, value);
        return this;
    }

    public R data(Map<String, Object> map){
        this.data = map;
        return this;
    }


    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
