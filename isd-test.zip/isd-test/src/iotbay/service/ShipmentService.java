package iotbay.service;


import iotbay.model.Shipment;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;


public interface ShipmentService {

    Shipment queryById(Integer id) throws SQLException;

    Shipment insert(Shipment shipment) throws SQLException;

    Shipment update(Shipment shipment) throws SQLException;

    boolean deleteById(Integer id) throws SQLException;

    Map<String, Object> findAllByPage(Map<String, Object> params) throws SQLException;

    List<Shipment> findAll(Shipment shipment) throws  SQLException;

}
