package iotbay.model;

public class Order {
    //Define the elements of the model
    private int orderID;
    private int customerID;
    //private String orderName;
    //private String orderDestination;
    //private String orderStatus;
    private int orderVolume;
    private String shippingStatus;

    //Getters and setters for the defined elements of the model

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getOrderVolume() {
        return orderVolume;
    }

    public void setOrderVolume(int orderVolume) {
        this.orderVolume = orderVolume;
    }

    public String getShippingStatus() {
        return shippingStatus;
    }

    public void setShippingStatus(String shippingStatus) {
        this.shippingStatus = shippingStatus;
    }


}