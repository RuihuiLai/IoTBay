package iotbay.dao;


import iotbay.model.Shipment;
import iotbay.utils.DataSourceUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ShipmentDao {


    public Shipment queryById(Integer id) throws SQLException {
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "SELECT id, customer_id customerId, address, shipment_method shipmentMethod, create_time createTime FROM shipment WHERE id = ?";
        return runner.query(sql,new BeanHandler<Shipment>(Shipment.class), id);
    }


    public Map<String, Object> queryAll(Shipment shipment, int limit, int page) throws SQLException {
        Map<String, Object> result = new HashMap<>(2);
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "SELECT id, customer_id AS customerId, address, shipment_method shipmentMethod, create_time createTime, order_id orderId, status FROM shipment WHERE customer_id = ? ";
        if (shipment.getId() != null){
            sql += "AND id =  " + shipment.getId();
        }
        sql += " LIMIT ?,?";
        result.put("rows", runner.query(sql,new BeanListHandler<Shipment>(Shipment.class), shipment.getCustomerId(), (page -1)*limit, limit));
        PreparedStatement preparedStatement = DataSourceUtils.getDataSource().getConnection().prepareStatement("SELECT COUNT(*) AS count FROM shipment WHERE customer_id = ?");
        preparedStatement.setObject(1, shipment.getCustomerId());
        ResultSet resultSet = preparedStatement.executeQuery();
        if (resultSet.next()) {
            result.put("count", resultSet.getInt(1));
        }
        return result;
    }

    public List<Shipment> findAll(Shipment shipment) throws SQLException {
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "SELECT id, customer_id AS customerId, address, shipment_method shipmentMethod, create_time createTime, order_id orderId, status FROM shipment WHERE customer_id = ? ";
        if (shipment.getId() != null){
            sql += "AND id =  " + shipment.getId();
        }
        return runner.query(sql,new BeanListHandler<>(Shipment.class),shipment.getCustomerId());
    }


    public int insert(Shipment shipment) throws SQLException {
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "INSERT INTO shipment(customer_id, address, shipment_method, order_id, status) VALUES (?, ?, ?, UUID_SHORT(), ?)";
        return runner.update(sql, shipment.getCustomerId(), shipment.getAddress(), shipment.getShipmentMethod(), shipment.getStatus());
    }



    public int update(Shipment shipment) throws SQLException {
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "UPDATE shipment SET address = ?, shipment_method =?, status =? WHERE id = ?";
        return runner.update(sql, shipment.getAddress(), shipment.getShipmentMethod(), shipment.getStatus(), shipment.getId());
    }


    public int deleteById(Integer id) throws SQLException {
        QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
        String sql = "DELETE FROM shipment WHERE id = ?";
        return runner.update(sql, id);
    }

}

